from pathlib import Path
import csv
import re
from urllib.request import Request, urlopen
from urllib.error import URLError, HTTPError
from html.parser import HTMLParser

BASE = Path(__file__).parent
OUTPUT = BASE / "output" / "extracted_links.csv"
URL = "https://example.com"

class LinkParser(HTMLParser):
    def __init__(self):
        super().__init__()
        self.links = []
        self._href = None
    def handle_starttag(self, tag, attrs):
        if tag.lower() == "a":
            self._href = dict(attrs).get("href")
    def handle_data(self, data):
        if self._href and data.strip():
            self.links.append((data.strip(), self._href))
    def handle_endtag(self, tag):
        if tag.lower() == "a":
            self._href = None

def main():
    OUTPUT.parent.mkdir(exist_ok=True)
    request = Request(URL, headers={"User-Agent": "StudentPortfolioDemo/1.0"})
    try:
        with urlopen(request, timeout=15) as response:
            html = response.read().decode("utf-8", errors="replace")
    except (URLError, HTTPError, TimeoutError) as exc:
        print(f"Could not access {URL}: {exc}")
        print("Check your internet connection and try again.")
        return

    parser = LinkParser()
    parser.feed(html)
    with OUTPUT.open("w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["Link Text", "URL"])
        writer.writerows(parser.links)
    print(f"Extracted {len(parser.links)} links to {OUTPUT}")

if __name__ == "__main__":
    main()
