# Web Data Extraction Automation

## Purpose
Opens a public demonstration website, extracts anchor text and URLs, and saves the results into a CSV report.

## Run
1. Make sure you have internet access.
2. Run `python main.py`.
3. Find `output/extracted_links.csv`.

## Skills demonstrated
HTTP requests, HTML parsing, structured data extraction, CSV reporting, error handling.

## Responsible use
Only automate websites where you have permission. Respect the site's terms, robots rules, rate limits, and privacy requirements. This demo targets `https://example.com` only.
