# RPA / Automation Student Portfolio

This portfolio contains three beginner-friendly automation demonstrations:
1. Excel Data Entry Automation
2. Local File Organizer Automation
3. Web Data Extraction Automation

## General requirements
- Python 3.10+
- Install each project's `requirements.txt` separately where needed.

## Important for your CV
Only list a project as completed after you run it, understand the code, and can explain or demonstrate it. These are Python automation demos, not UiPath projects. Do not claim Outlook integration or UiPath experience from these examples.
