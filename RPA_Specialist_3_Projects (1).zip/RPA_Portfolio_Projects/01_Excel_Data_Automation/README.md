# Excel Data Entry Automation

## Purpose
Reads a sales spreadsheet, validates required fields, calculates line totals, and creates a formatted Excel report.

## Setup
1. Install Python 3.10 or newer.
2. Open a terminal in this folder.
3. Run `python -m pip install -r requirements.txt`.
4. Create `input/sales_data.xlsx` with columns `Product`, `Quantity`, `Unit Price`. You can open the supplied CSV in Excel and save it as `sales_data.xlsx`.
5. Run `python main.py`.
6. Find the report at `output/sales_report.xlsx`.

## Skills demonstrated
Excel processing, data validation, calculations, exception handling, automated reporting.

## Note
This is a Python automation demonstration, not a UiPath workflow.
