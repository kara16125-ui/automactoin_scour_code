from pathlib import Path
from openpyxl import load_workbook, Workbook
from openpyxl.styles import Font, PatternFill
from openpyxl.utils import get_column_letter

BASE = Path(__file__).parent
INPUT = BASE / "input" / "sales_data.xlsx"
OUTPUT = BASE / "output" / "sales_report.xlsx"

def main():
    OUTPUT.parent.mkdir(exist_ok=True)
    if not INPUT.exists():
        print(f"Input file not found: {INPUT}")
        return

    wb = load_workbook(INPUT)
    ws = wb.active
    headers = [cell.value for cell in ws[1]]
    required = {"Product", "Quantity", "Unit Price"}
    if not required.issubset(set(headers)):
        raise ValueError(f"Excel must contain columns: {sorted(required)}")

    product_col = headers.index("Product") + 1
    quantity_col = headers.index("Quantity") + 1
    price_col = headers.index("Unit Price") + 1

    report = Workbook()
    out = report.active
    out.title = "Sales Report"
    out.append(["Product", "Quantity", "Unit Price", "Total", "Validation"])
    totals = 0

    for row in ws.iter_rows(min_row=2, values_only=True):
        product = row[product_col - 1]
        quantity = row[quantity_col - 1]
        price = row[price_col - 1]
        if not product or quantity is None or price is None:
            out.append([product, quantity, price, None, "Missing data"])
            continue
        try:
            line_total = float(quantity) * float(price)
            totals += line_total
            out.append([product, quantity, price, line_total, "OK"])
        except (TypeError, ValueError):
            out.append([product, quantity, price, None, "Invalid number"])

    out.append([])
    out.append(["GRAND TOTAL", None, None, totals, ""])
    for cell in out[1]:
        cell.font = Font(bold=True, color="FFFFFF")
        cell.fill = PatternFill("solid", fgColor="245A81")
    for column in out.columns:
        max_len = max(len(str(c.value or "")) for c in column)
        out.column_dimensions[get_column_letter(column[0].column)].width = min(max_len + 3, 32)
    report.save(OUTPUT)
    print(f"Report created: {OUTPUT}")
    print(f"Grand total: {totals:.2f}")

if __name__ == "__main__":
    main()
