# Email Attachment & File Organizer Automation

## Purpose
Demonstrates the file-handling part of an office automation workflow: scans a sample inbox folder, sorts supported documents by file type, avoids overwriting files, and writes an activity log.

## Run
`python main.py`

## Important
This demo uses local sample files. It does **not** connect to or read a real email account, and it does not send email. A real Outlook/Gmail integration would require authorized account access and credentials.

## Skills demonstrated
File automation, folder organization, filename sanitization, duplicate handling, logging, exception-aware workflow design.
