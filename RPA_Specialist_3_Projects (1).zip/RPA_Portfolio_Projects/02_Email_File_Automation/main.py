from pathlib import Path
import shutil
import re
from datetime import datetime

BASE = Path(__file__).parent
INBOX = BASE / "sample_inbox"
DEST = BASE / "organized_files"
LOG = BASE / "automation_log.txt"
ALLOWED = {".pdf", ".docx", ".xlsx", ".csv", ".txt", ".png", ".jpg", ".jpeg"}

def safe_name(name):
    name = re.sub(r"[^A-Za-z0-9._-]+", "_", name)
    return name.strip("._") or "unnamed_file"

def main():
    DEST.mkdir(exist_ok=True)
    moved = 0
    skipped = 0
    lines = [f"Run time: {datetime.now().isoformat(timespec='seconds')}"]
    for item in INBOX.iterdir():
        if not item.is_file():
            continue
        if item.suffix.lower() not in ALLOWED:
            skipped += 1
            lines.append(f"SKIPPED (unsupported): {item.name}")
            continue
        folder = DEST / item.suffix.lower().lstrip(".")
        folder.mkdir(exist_ok=True)
        target = folder / safe_name(item.name)
        if target.exists():
            target = folder / f"{target.stem}_{datetime.now():%Y%m%d%H%M%S}{target.suffix}"
        shutil.copy2(item, target)
        moved += 1
        lines.append(f"COPIED: {item.name} -> {target.relative_to(BASE)}")
    lines.extend([f"Copied: {moved}", f"Skipped: {skipped}", "-" * 40])
    with LOG.open("a", encoding="utf-8") as f:
        f.write("\\n".join(lines) + "\\n")
    print("\\n".join(lines))

if __name__ == "__main__":
    main()
